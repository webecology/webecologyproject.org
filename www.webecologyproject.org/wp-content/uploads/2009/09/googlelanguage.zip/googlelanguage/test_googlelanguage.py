from googlelanguage import *

print lang_detect("this is a sentence in English")

print lang_translate("comment dit on 'WebEcology' en francais?", dest_lang="en")


def gogol_lang_detect(text):
    return "Russian"